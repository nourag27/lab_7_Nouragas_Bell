﻿namespace Lab_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Read_channel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Current_data = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.Serial_start = new System.Windows.Forms.Button();
            this.Serial_stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Read_channel
            // 
            this.Read_channel.Location = new System.Drawing.Point(54, 161);
            this.Read_channel.Name = "Read_channel";
            this.Read_channel.Size = new System.Drawing.Size(114, 58);
            this.Read_channel.TabIndex = 2;
            this.Read_channel.Text = "Read in channel";
            this.Read_channel.UseVisualStyleBackColor = true;
            this.Read_channel.Click += new System.EventHandler(this.Read_channel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(523, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "label1";
            // 
            // Current_data
            // 
            this.Current_data.AutoSize = true;
            this.Current_data.Location = new System.Drawing.Point(69, 320);
            this.Current_data.Name = "Current_data";
            this.Current_data.Size = new System.Drawing.Size(98, 20);
            this.Current_data.TabIndex = 4;
            this.Current_data.Text = "Current data";
            this.Current_data.Click += new System.EventHandler(this.Current_data_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(510, 320);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM6";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1_DataReceived);
            // 
            // Serial_start
            // 
            this.Serial_start.Location = new System.Drawing.Point(54, 62);
            this.Serial_start.Name = "Serial_start";
            this.Serial_start.Size = new System.Drawing.Size(100, 49);
            this.Serial_start.TabIndex = 6;
            this.Serial_start.Text = "Serial start";
            this.Serial_start.UseVisualStyleBackColor = true;
            this.Serial_start.Click += new System.EventHandler(this.Serial_start_Click);
            // 
            // Serial_stop
            // 
            this.Serial_stop.Location = new System.Drawing.Point(510, 62);
            this.Serial_stop.Name = "Serial_stop";
            this.Serial_stop.Size = new System.Drawing.Size(100, 49);
            this.Serial_stop.TabIndex = 7;
            this.Serial_stop.Text = "Serial stop";
            this.Serial_stop.UseVisualStyleBackColor = true;
            this.Serial_stop.Click += new System.EventHandler(this.Serial_stop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 541);
            this.Controls.Add(this.Serial_stop);
            this.Controls.Add(this.Serial_start);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Current_data);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Read_channel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Read_channel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Current_data;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button Serial_start;
        private System.Windows.Forms.Button Serial_stop;
    }
}

